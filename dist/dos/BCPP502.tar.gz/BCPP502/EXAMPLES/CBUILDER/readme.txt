The examples here are intended to show interoperability between OWL and VCL 
and between MFC and VCL.

Documentation for these examples may be found in the file BC5\DOC\OWLVCL.DOC

The header files in the INCLUDE subdirectory are updates for the files shipped 
with C++Builder release 1.0.  See BC5\DOC\OWLVCL.DOC for more info.