----------------------------------------------------------------------------
 Borland C++
 Copyright (c) 1987, 1996 Borland International Inc.  All Rights Reserved.
----------------------------------------------------------------------------

TITLE:
    DOS EXAMPLES

BARCHART - Uses the Borland Graphics Interface (BGI) to dipslay a bar chart.
HELLO    - A simple DOS program.
MYMAIN   - Demonstrates how to pass command line arguments to your program.
VCIRC    - Uses BGI to display a circle.

See also the example BGIDEMO located in \BC5\BGI.


