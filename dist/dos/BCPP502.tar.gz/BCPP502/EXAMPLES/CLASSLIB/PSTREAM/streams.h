/*------------------------------------------------------------------------*/
/*                                                                        */
/*  STREAMS.H                                                             */
/*                                                                        */
/*  Copyright Borland International, 1993                                 */
/*                                                                        */
/*  Streaming example header file                                         */
/*                                                                        */
/*------------------------------------------------------------------------*/

#define CM_FILENEW  24331
#define CM_FILEOPEN 24332
#define CM_FILESAVE 24333
#define CM_FILESAVEAS 24334
#define CM_EXIT 24310

#define CM_EDITLINE    201
#define CM_EDITRECTANGLE    202
#define CM_EDITCAPTIONEDRECTANGLE 203
#define CM_EDITFILLEDRECTANGLE    204
#define CM_EDITELLIPSE 205
#define CM_EDITCAPTIONEDELLIPSE 206
#define CM_EDITFILLEDELLIPSE 207

#define CM_HELPABOUT    24346

#define ELLIPSE_CURSOR 1
#define LINE_CURSOR    2
#define RECT_CURSOR    3

#define IDD_INPUTEDITBOX 501
#define IDD_TOP 502
#define IDD_CENTER 503
#define IDD_BOTTOM 504
#define IDD_POSITIONBOX 505
