#if !defined( __TODODEFS_H )
#define __TODODEFS_H

//---------------------------------------------------------------------
//
//  TODODEFS.H
//
//      Copyright (c) 1991, 1993 by Borland International
//      All Rights Reserved.
//
//  defines various event ids
//
//---------------------------------------------------------------------

#define IDM_QUIT      101
#define IDM_NEW_LIST  102
#define IDM_OPEN      103
#define IDM_SAVE      104
#define IDM_SAVEAS    105
#define IDM_EDIT      106
#define IDM_NEW_ENTRY 107
#define IDM_DEL_ENTRY 108
#define IDM_ABOUT     109

#define IDC_LISTBOX   120

#define IDE_DATEENT   131
#define IDE_DATEDUE   132
#define IDE_TEXT      133
#define IDE_LOW       134
#define IDE_MEDIUM    135
#define IDE_HIGH      136
#define IDE_PRIORITY  137

#endif  // __TODODEFS_H

