//iocolors.h
//header file
//////////////////
//Programmers:  //
//Robert Fahey  //
//KENNETH HANSEN//
//////////////////
//
//FUNCTIONS:
//txtcolor(int clr)      - changes text color
//txtbackground(int clr) - changes background color
//delay(int dly)         - delays program (1/1000 of a second)
//clearWindows()         - clears all windwos
//int intlength(int num) - returns # of characters in an integer
//makeWindows(int c1, int r1, int c2, int r2, int col=BLUE, int lines=WHITE,
//       int bac=BLACK)  - makes cool window thing(background color, line color,
//                         and frame background have a default of BLUE, WHITE
//                         and BLACK respectively


#ifndef IOCOLORS_H //makes sure header is not used twice
#define IOCOLORS_H //if header is not used twice define header and use code

#include <string>     //strings
#include <values.h>   //values
#include <windows.h>  //allows for color change(handle and attribute)
#include <conio.h>    //allows for changing conio window color
#include <time.h>     //for rollover
#include <dos.h>      //for rollover
#include <iomanip.h>  //input output(cin.ignore)

void txtcolor(int clr)
/*************************************/
/*changes textcolor of console output*/
/*************************************/
//KEN HANSEN
{
   HANDLE hnd = GetStdHandle(STD_OUTPUT_HANDLE);//finds handle of console window
   CONSOLE_SCREEN_BUFFER_INFO csbi;             //object to hold current colors
   GetConsoleScreenBufferInfo(hnd, &csbi);      //get current colors
   int current=csbi.wAttributes;                //store colors into variable

   //change textcolor without changing background color
   SetConsoleTextAttribute (hnd,current-(current%16)+clr);
   textcolor(clr);                              //changes window color
}

void txtbackground(int clr)
//KEN HANSEN
/******************************************/
/*changes textbackground of console output*/
/******************************************/
{
   //if to fix background color problems
   if (clr>7)
   clr-=8;    //makes color dark

   HANDLE hnd = GetStdHandle(STD_OUTPUT_HANDLE);//finds handle of console window
   CONSOLE_SCREEN_BUFFER_INFO csbi;             //object to hold current colors
   GetConsoleScreenBufferInfo(hnd, &csbi);      //get current colors
   int current=csbi.wAttributes;                //store colors in variable

   //change text background without changing textcolor
   SetConsoleTextAttribute (hnd,(current%16)+clr*16);
   textbackground(clr);                         //changes window color
}

void delay(int dly)
{
//KENNETH HANSEN

     //--------------------------------------------------
       clock_t time1=clock(),time2=time1+dly;
       while (time1<time2)
       time1=clock();
     //-------------------------------------------------
}

void clearWindows (int col3)
//Robert Fahey
// this method clears all windows
{
   if (kbhit())
   	cin.ignore(80,'\n');
      
   txtbackground (col3);
   window (1,1,80,25);
   clrscr();	
}

void makeWindows (int c1, int r1, int c2, int r2,
						int col=BLUE, int lines=WHITE, int bac=BLACK,
                  int col3=LIGHTGRAY)
//Robert Fahey
// this method creates a three dimensional window
{
	int x,y;      //x and y for borders
   //clears the windows
	clearWindows (col3);
   //creates the front window
   textcolor(lines);
   textbackground (bac);
   gotoxy(c1-2,r1-1);
   window (c1-3, r1-1, c2+3, r2+1);
   clrscr();

   //creates border
   for (x=2; x<c2-c1+6; x++)
   {
   	gotoxy(x,1);
      putch(205);
   }                 
   for (x=2; x<c2-c1+6; x++)
   {
   	gotoxy(x,r2-r1+3);
      putch(205);
   }
   for (y=1; y<r2-r1+3; y++)
   {
   	gotoxy(2,y);
      putch(186);
   }
   for (y=1; y<r2-r1+3; y++)
   {
   	gotoxy(c2-c1+6,y);
      putch(186);
   }

   //creates corners
   gotoxy (2,1);
   putch (201);
   gotoxy (c2-c1+6,r2-r1+3);
   putch (188);
   gotoxy (2,r2-r1+3);
   putch (200);
   gotoxy (c2-c1+6,1);
   putch (187);
   txtbackground(col);
   window (c1, r1, c2, r2);
   clrscr();
}

int intlength(int num)
//KENNETH HANSEN
{
   int count=0;
   do
    {
     count++;
     num/=10;
    }
   while (num>=1);
   return count;
}

#endif //end of header